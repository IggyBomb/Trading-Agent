# Long-Term Deep-Dives — QUALITY names — 2026-09-30

47 Deep-Dives (48 QUALITY names from `LT_SCREEN_2026-09-29`; GOOG and GOOGL share one report). Each report follows `.trading/agents/long-term-analyst.md` Deep-Dive mode, sections 0–12: Recent Context (web-researched) → Business → Routing → Lynch → Penman → Koller valuation with Benninga sensitivities → Mauboussin PIE → Fisher → Ilmanen → Compounder screen → Sector appendix → 5-year ratio trends → Final verdict. Prices: Sept 29, 2026 close (yfinance).

**Outcome:** 42 confirmed QUALITY · 4 moved to WATCH (PGR, CINF, BEZ.L, FIS provisional) · 1 moved to TRADE ONLY (ALNY). None reaches COMPOUNDER at today's price (that needs price ≤ Bear value with a 7+/9 business; only BZU.MI trades below Bear, and its business scores 6/9).

| # | Ticker | Verdict | MoS | F | Price | Bear / Base / Bull | Base (€) | Price/Base | Note |
|---|---|---|---|---|---|---|---|---|---|
| 1 | **FISV** | QUALITY | BASE | 71 | $45.36 | $33.42 / $86.46 / $120.92 | €76.22 | 0.52 |  |
| 2 | **T** | QUALITY | BASE | 65 | $24.48 | $18.44 / $40.82 / $51.66 | €35.98 | 0.60 |  |
| 3 | **STZ** | QUALITY | BASE | 67 | $112.77 | $97.24 / $185.03 / $219.47 | €163.10 | 0.61 |  |
| 4 | **ORCL** | QUALITY | BASE | 67 | $137.79 | $77.59 / $216.01 / $435.48 | €190.42 | 0.64 |  |
| 5 | **TRGP** | QUALITY | BASE | 63 | $273.49 | $144.73 / $428.08 / $722.70 | €377.35 | 0.64 |  |
| 6 | **BZU.MI** | QUALITY | BEAR | 69 | €37.50 | €43.01 / €57.16 / €67.24 | €57.16 | 0.66 |  |
| 7 | **G24.DE** | QUALITY | BASE | 77 | €67.10 | €62.33 / €100.53 / €130.36 | €100.53 | 0.67 |  |
| 8 | **HIG** | QUALITY | BASE | 86 | $125.85 | $97.25 / $183.04 / $246.13 | €161.35 | 0.69 |  |
| 9 | **HAS** | QUALITY | BASE | 63 | $88.26 | $70.93 / $124.15 / $164.36 | €109.44 | 0.71 |  |
| 10 | **GDDY** | QUALITY | BASE | 69 | $94.06 | $82.43 / $130.54 / $167.82 | €115.07 | 0.72 |  |
| 11 | **WTW** | QUALITY | BASE | 70 | $288.57 | $235.11 / $387.74 / $497.27 | €341.79 | 0.74 |  |
| 12 | **GOOG** | QUALITY | BASE | 84 | $337.32 | $275.70 / $452.24 / $684.05 | €398.65 | 0.75 | returns on new capex capped at 20%; still QUALITY (GOOGL also BASE) |
| 13 | **BMPS.MI** | QUALITY | BASE | 72 | €11.92 | €10.80 / €15.95 / €20.37 | €15.95 | 0.75 |  |
| 14 | **HNR1.DE** | QUALITY | BASE | 84 | €256.20 | €159.99 / €340.36 / €469.39 | €340.36 | 0.75 |  |
| 15 | **GL** | QUALITY | BASE | 85 | $166.08 | $112.94 / $216.14 / $290.54 | €190.52 | 0.77 |  |
| 16 | **EIX** | QUALITY | BASE | 57 | $53.56 | $46.31 / $69.54 / $95.19 | €61.30 | 0.77 |  |
| 17 | **INTU** | QUALITY | BASE | 78 | $268.03 | $213.94 / $315.99 / $409.41 | €278.55 | 0.85 |  |
| 18 | **ICG.L** | QUALITY | BASE | 73 | 1,831p | 1,484p / 2,143p / 2,644p | €24.99 | 0.85 |  |
| 19 | **FICO** | QUALITY | BASE | 84 | $617.87 | $468.20 / $716.11 / $980.03 | €631.25 | 0.86 |  |
| 20 | **ALL** | QUALITY | BASE | 64 | $225.42 | $146.26 / $259.59 / $349.47 | €228.83 | 0.87 | still QUALITY on an 18% through-cycle ROE (Base cut to $259.59 from $400) |
| 21 | **APP** | QUALITY | BASE | 92 | $305.66 | $224.81 / $351.97 / $526.35 | €310.26 | 0.87 |  |
| 22 | **KKR** | QUALITY | BASE | 74 | $93.18 | $65.68 / $104.95 / $138.25 | €92.52 | 0.89 |  |
| 23 | **MTX.DE** | QUALITY | BASE | 69 | €371.00 | €240.56 / €417.59 / €574.82 | €417.59 | 0.89 |  |
| 24 | **CB** | QUALITY | BASE | 74 | $332.08 | $225.46 / $372.77 / $502.57 | €328.60 | 0.89 |  |
| 25 | **INCY** | QUALITY | BASE | 80 | $123.20 | $102.88 / $138.25 / $165.77 | €121.87 | 0.89 |  |
| 26 | **ADBE** | QUALITY | BASE | 77 | $233.17 | $196.60 / $261.59 / $328.94 | €230.60 | 0.89 |  |
| 27 | **NWG.L** | QUALITY | BASE | 72 | 688p | 560p / 771p / 995p | €8.99 | 0.89 |  |
| 28 | **HSX.L** | QUALITY | BASE | 77 | 1,880p | 1,246p / 2,107p / 2,771p | €24.58 | 0.89 |  |
| 29 | **BX** | QUALITY | BASE | 79 | $114.00 | $71.66 / $124.89 / $176.72 | €110.09 | 0.91 |  |
| 30 | **NVDA** | QUALITY | BASE | 87 | $227.21 | $136.92 / $247.18 / $422.54 | €217.89 | 0.92 |  |
| 31 | **EDV.L** | QUALITY | BASE | 87 | 4,284p | 3,447p / 4,643p / 5,902p | €54.15 | 0.92 |  |
| 32 | **EXPE** | QUALITY | BASE | 67 | $266.33 | $191.14 / $287.71 / $376.80 | €253.62 | 0.93 |  |
| 33 | **TRV** | QUALITY | BASE | 75 | $363.21 | $213.36 / $390.65 / $525.58 | €344.36 | 0.93 |  |
| 34 | **SBAC** | QUALITY | BASE | 64 | $162.81 | $141.37 / $173.37 / $203.31 | €152.83 | 0.94 | valued on company AFFO guidance; still QUALITY |
| 35 | **AOS** | QUALITY | BASE | 71 | $58.02 | $44.04 / $61.73 / $76.87 | €54.41 | 0.94 |  |
| 36 | **BKNG** | QUALITY | BASE | 82 | $162.34 | $120.37 / $172.62 / $221.42 | €152.17 | 0.94 |  |
| 37 | **ERIE** | QUALITY | BASE | 72 | $222.43 | $161.78 / $235.60 / $287.54 | €207.68 | 0.94 |  |
| 38 | **CS.PA** | QUALITY | BASE | 73 | €43.49 | €27.76 / €45.51 / €60.19 | €45.51 | 0.96 |  |
| 39 | **RL** | QUALITY | BASE | 69 | $355.92 | $243.70 / $366.26 / $475.00 | €322.86 | 0.97 |  |
| 40 | **BAMI.MI** | QUALITY | BASE | 67 | €16.25 | €11.37 / €16.65 / €21.67 | €16.65 | 0.98 |  |
| 41 | **UNI.MI** | QUALITY | BASE | 70 | €27.21 | €17.02 / €27.85 / €37.45 | €27.85 | 0.98 | still QUALITY on a 15% ROE, but only 2% below Base |
| 42 | **ITRI** | QUALITY | BASE | 62 | $87.39 | $53.79 / $88.63 / $120.45 | €78.13 | 0.99 |  |
| 43 | **FIS** | WATCH (QUALITY) — provisional | BASE | 54 | $33.35 | $11.04 / $38.12 / $53.21 | €33.61 | 0.87 | WATCH — provisional: $13.5bn Issuer Solutions deal closed after the model base year |
| 44 | **BEZ.L** | WATCH (QUALITY) | NONE (< Bull) | 67 | 1,308p | 755p / 1,214p / 1,596p | €14.16 | 1.08 | WATCH (was QUALITY): H1 profit roughly halved, combined ratio 93.3%, rates −6.5% |
| 45 | **CINF** | WATCH (COMPOUNDER) | NONE (< Bull) | 55 | $161.13 | $94.51 / $139.81 / $189.31 | €123.24 | 1.15 | WATCH (was QUALITY): Q2 combined ratio 100.8%; ROE ex-equity gains ~11% |
| 46 | **PGR** | WATCH (QUALITY) | NONE (< Bull) | 64 | $210.52 | $83.54 / $167.43 / $224.41 | €147.59 | 1.26 | WATCH (was QUALITY): valued on 25% through-cycle ROE; Aug combined ratio +6.2pts |
| 47 | **ALNY** | TRADE ONLY | BASE | 84 | $254.07 | $152.15 / $297.29 / $477.18 | €262.06 | 0.85 | TRADE ONLY (was QUALITY): operating losses FY22–24; sustained ROIC not yet demonstrated |

**Widest margins of safety (price/Base):** FISV 0.52, T 0.60, STZ 0.61, ORCL 0.64, TRGP 0.64, BZU.MI 0.66, G24.DE 0.67, HIG 0.69, HAS 0.71, GDDY 0.72.

**Low-confidence valuations (read the report before relying on the number):** ORCL (terminal value 87% of EV, negative FCF, ~$124bn net debt), TRGP (TV 88%, growth input includes commodity effects), FIS (pre-transaction base year), NVDA (beta clipped from 2.22), EIX (wildfire-liability tail not modelled), FISV (guide −1% to 0% vs consensus used).

**Macro backdrop for all:** US 10Y 5.27%, gilt 5.38%, BTP 4.60% (BTP-Bund > 100bp intraday), regime REFLATION → stagflation-lite. Every Base value is shown with a ±1pp discount-rate sensitivity in its report.